import app from './app'
// só posso fazer isso aqui se adicionar o sucrase yarn add sucrase
app.listen(3001)

// para rodar  yarn sucrase-node src/server.js
