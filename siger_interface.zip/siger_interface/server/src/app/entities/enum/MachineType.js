module.exports = ['Non-IMRT', 'IMRT', 'SRS/SBRT', 'TODAS']
