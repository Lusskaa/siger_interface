module.exports = ['Mecânico', 'Dosimétrico', 'Segurança', 'Gating respiratório']
