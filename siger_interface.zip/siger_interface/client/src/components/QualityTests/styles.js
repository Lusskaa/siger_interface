import styled from "styled-components"

export const Container = styled.div`
    width: 100%;
    
    

`
export const ContainerItens = styled.div`
    height: 50px;
    display: flex;
    align-items: center;
    justify-items: center;
    border-bottom: 2px solid #CAD2D3;

`
export const P = styled.div `
        width: 200px ;
        display: flex;
        justify-content: center;

`
export const ContainerTests = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    

`
export const ContainerTitles = styled.div`
    display: flex;
    flex-direction: row;
    align-items: center;
    
    margin-bottom: 30px;

    h3{
        width: 120px;
        margin: 0 40px 0 35px;
        
    }
    


`

