import styled from 'styled-components'

export const Container = styled.div`
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    

`
export const HomeImg = styled.img`
    height: 250px;
    


`
export const ContainerWelcome = styled.div`
    display: flex;
    flex-direction: row;
    width: 1000px;
    

`
export const Welcome = styled.p`
    font-style: normal;
    font-weight: 400;
    font-size: 24px;
    line-height: 28px;
    text-align: center;
    align-self: center;

    color: #000000;


`
/* export const Container = styled.div`

`
export const Container = styled.div`

`
export const Container = styled.div`

` */